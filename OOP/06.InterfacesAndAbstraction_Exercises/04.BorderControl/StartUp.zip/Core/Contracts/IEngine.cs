﻿namespace _04.BorderControl.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
