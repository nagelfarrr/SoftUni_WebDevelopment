﻿namespace _04.BorderControl.Models.Contracts
{
    public interface IRobot : IPopulation
    {
        public string Model { get; }
        
    }
}
