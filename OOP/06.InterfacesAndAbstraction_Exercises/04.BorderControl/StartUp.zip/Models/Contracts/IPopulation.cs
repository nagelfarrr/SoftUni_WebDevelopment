﻿namespace _04.BorderControl.Models.Contracts
{
    public interface IPopulation
    {
        public string Id { get; }
    }
}
