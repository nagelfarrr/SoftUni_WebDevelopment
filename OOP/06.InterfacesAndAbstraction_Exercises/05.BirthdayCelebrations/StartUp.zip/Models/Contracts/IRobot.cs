﻿namespace BirthdayCelebrations.Models.Contracts
{
    public interface IRobot : IPopulation
    {
        public string Model { get; }
        
    }
}
