﻿namespace BirthdayCelebrations.Models.Contracts
{
    public interface IPopulation
    {
        public string Id { get; }
        
    }
}
