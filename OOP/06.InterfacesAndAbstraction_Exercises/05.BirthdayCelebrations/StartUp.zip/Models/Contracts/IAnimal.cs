﻿namespace BirthdayCelebrations.Models.Contracts
{
    public interface IAnimal : IBirthable
    {
        public string Name { get; }

    }
}
