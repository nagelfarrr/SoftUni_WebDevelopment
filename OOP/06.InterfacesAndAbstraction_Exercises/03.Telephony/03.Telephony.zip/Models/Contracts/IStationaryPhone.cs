﻿namespace Telephony.Models.Contracts
{
    public interface IStationaryPhone
    {
        string Call(string phoneNumber);
    }
}
