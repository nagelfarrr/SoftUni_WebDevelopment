﻿namespace Telephony.Models.Contracts
{
    public interface ISmartPhone 
    {
        string Browse(string url);
    }
}
