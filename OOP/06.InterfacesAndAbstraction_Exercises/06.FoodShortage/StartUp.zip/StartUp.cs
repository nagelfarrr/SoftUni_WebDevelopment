﻿namespace _06.FoodShortage
{
    
    using _06.FoodShortage.Core;

    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
