﻿namespace _06.FoodShortage.Models.Contracts

{
    public interface IBirthable
    {
        public string Birthdate { get; }
    }
}
