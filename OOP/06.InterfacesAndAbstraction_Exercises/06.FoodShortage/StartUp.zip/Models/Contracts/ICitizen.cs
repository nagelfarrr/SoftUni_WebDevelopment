﻿namespace _06.FoodShortage.Models.Contracts
{
    public interface ICitizen
    {
       
        public int Age { get; }

    }
}
