﻿namespace _06.FoodShortage.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
