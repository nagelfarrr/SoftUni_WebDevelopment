﻿namespace _07.MilitaryElite.Models.Contracts
{
    public interface ISpecialisedSoldier
    {
        string Corps { get;  }
    }
}
