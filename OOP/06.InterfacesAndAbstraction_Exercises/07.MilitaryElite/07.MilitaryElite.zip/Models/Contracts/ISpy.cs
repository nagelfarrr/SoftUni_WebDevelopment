﻿namespace _07.MilitaryElite.Models.Contracts
{
    public interface ISpy
    {
        public int CodeNumber { get; set; }
    }
}
