﻿namespace BookingApp.Models.Rooms
{
    public class DoubleBed : Room
    {
        public DoubleBed() : base(2)
        {
        }
    }
}
