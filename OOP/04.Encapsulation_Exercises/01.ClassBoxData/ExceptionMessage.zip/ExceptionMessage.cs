﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.ClassBoxData
{
    public static class ExceptionMessage
    {
        public const string NumberIsBelowZero = "{0} cannot be zero or negative.";
    }
}
