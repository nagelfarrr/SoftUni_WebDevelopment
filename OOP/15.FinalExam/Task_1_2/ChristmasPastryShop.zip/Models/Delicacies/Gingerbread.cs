﻿namespace ChristmasPastryShop.Models.Delicacies
{
    public class Gingerbread :Delicacy
    {
        public Gingerbread(string delicacyName) : base(delicacyName, 4.00)
        { }
    }
}
