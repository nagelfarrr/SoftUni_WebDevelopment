﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-KQ1NJBD\SQLEXPRESS;Database=Trucks;Trusted_Connection=True;Integrated Security = true;TrustServerCertificate = true;";
    }
}