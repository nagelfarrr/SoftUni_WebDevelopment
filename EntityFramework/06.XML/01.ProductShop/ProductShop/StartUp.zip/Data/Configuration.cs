﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-KQ1NJBD\SQLEXPRESS;Database=ProductShop;Trusted_Connection=True;Integrated Security = true;TrustServerCertificate = true;";
    }
}
