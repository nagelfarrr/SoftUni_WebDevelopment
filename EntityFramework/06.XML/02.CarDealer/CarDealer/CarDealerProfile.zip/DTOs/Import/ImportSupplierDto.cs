﻿namespace CarDealer.DTOs.Import
{
    public class ImportSupplierDto
    {
        public string Name { get; set; } = null!;

        public bool IsImporter { get; set; }
    }
}
