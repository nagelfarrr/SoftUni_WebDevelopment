﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=DESKTOP-KQ1NJBD\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True;Integrated Security = true;TrustServerCertificate = true;";
    }
}
